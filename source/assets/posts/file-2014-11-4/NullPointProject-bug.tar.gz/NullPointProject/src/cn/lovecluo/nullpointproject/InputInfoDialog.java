package cn.lovecluo.nullpointproject;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Dialog;
import android.content.Context;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import cn.lovecluo.widget.form.BaseFormElement;
import cn.lovecluo.widget.form.BaseFormElement.ElementPosition;
import cn.lovecluo.widget.form.FormElementModel;

/** 
 * Create by luozc at Oct 20, 2014
 */
public class InputInfoDialog {

    private FormElementModel mModels;
    private Context mContext;
    private List<BaseFormElement> mPickerElements;
    private OnSubmitListener mSubmitListener = null;
    
    public InputInfoDialog(Context context, FormElementModel models) {
        this.mContext = context;
        this.mModels = models;
        mPickerElements = new ArrayList<BaseFormElement>();
    }
    
    public void addOnSubmitListener(OnSubmitListener listener){
        this.mSubmitListener = listener;
    }
    
    public void showDialog(){
        InnnerInputDialog dialog = new InnnerInputDialog(mContext);
        Window dialogWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        WindowManager m = (WindowManager) mContext
                .getSystemService(Context.WINDOW_SERVICE);
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        lp.width = (int) (m.getDefaultDisplay().getWidth() * 0.8f); // 宽度
        lp.height = LayoutParams.WRAP_CONTENT; // 高度
        dialogWindow.setAttributes(lp);
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
    }
    private BaseFormElement getFormElement(FormElementModel model, ElementPosition position) {
        Class<? extends BaseFormElement> clazz = model.getType().getValue();
        BaseFormElement element = null;
        try {
            Class[] parameterTypes={Context.class, FormElementModel.class}; 
            //根据参数类型获取相应的构造函数
            Constructor<? extends BaseFormElement> constructor=clazz.getConstructor(parameterTypes);
            //参数数组
            Object[] parameters={mContext, model};
            //根据获取的构造函数和参数，创建实例
            element=(BaseFormElement) constructor.newInstance(parameters);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return element;
    }
    
    class InnnerInputDialog extends Dialog {


        private LinearLayout mContainer = null;
        
        public InnnerInputDialog(Context context, int theme) {
            super(context, theme);
            this.initView();
        }

        private void initView() {
            this.setContentView(R.layout.input_dialog_content);
            mContainer = (LinearLayout) this.findViewById(R.id.input_container);
            BaseFormElement element = getFormElement(mModels, ElementPosition.TOP);
            mPickerElements.add(element);
            mContainer.addView(element, 0);
            Button button = (Button) mContainer.findViewById(R.id.submit_btn);
            button.setOnClickListener(new View.OnClickListener() {
                
                @Override
                public void onClick(View v) {
                    InnnerInputDialog.this.dismiss();
                    onSubmitClick(v);
                }
            });
        }
        public InnnerInputDialog(Context context) {
            this(context, R.style.Dialog);
        }
    }
    
    private void onSubmitClick(View view) {
        if (mSubmitListener != null) {
            Map<String, Object> result = new HashMap<String, Object>();
            for (BaseFormElement element : mPickerElements) {
                result.put(element.getKey(), element.getValue());
            }
            mSubmitListener.onSubmit(result);
        } // end if
    }
    public interface  OnSubmitListener {
        public void onSubmit(Map<String, Object> result);
    }
    
}
