package cn.lovecluo.widget.form;

import java.util.ArrayList;
import java.util.List;

import kankan.wheel.widget.OnWheelChangedListener;
import kankan.wheel.widget.OnWheelScrollListener;
import kankan.wheel.widget.WheelView;
import kankan.wheel.widget.adapters.AbstractWheelTextAdapter;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import cn.lovecluo.nullpointproject.R;
import cn.lovecluo.tools.DebugLog;

/** 
 * Create by luozc at Sep 12, 2014
 */
public class CityPickerElement extends PickerElement{

    private View mContentView;
    
    private List<CityNode> mCitys;
    private String mCitysStr;

    private WheelView mProvicePicker;
    private WheelView mCityPicker;

    private ProviceAdapter mProviceAdapter;
    private CountryAdapter mCityAdapter;
    
    public CityPickerElement(Context context, FormElementModel model) {
        super(context, model);
    }

    @Override
    public String getValue() {
        return mCityAdapter.getItemText(mCityPicker.getCurrentItem()).toString();
    }

    @Override
    protected View getView() {
        this.initView();
        this.initListener();
        return mContentView;
    }

    @Override
    public boolean checkValue() {
        return true;
    }

    @Override
    protected void preData() {
        this.mCitys = new ArrayList<CityNode>();
        mCitysStr = mContext.getString(R.string.cities);
        String[] provinces = mCitysStr.split(",");
        for (String provice : provinces) {
            String[] proviceDetail = provice.split(":");
            CityNode proviceNode = new CityNode();
            proviceNode.setNodeName(proviceDetail[0]);
            String[] countrys = proviceDetail[1].split("\\|");
            for (String country : countrys) {
                CityNode countryNode = new CityNode();
                countryNode.setNodeName(country);
                proviceNode.addChildNode(countryNode);
            }
            mCitys.add(proviceNode);
        }
    }
  
    private void initView() {
        mContentView = LayoutInflater.from(mContext).inflate(R.layout.city_picker, null);
        this.mProvicePicker = (WheelView) mContentView.findViewById(R.id.provice_picker);
        this.mProvicePicker.setVisibleItems(3);
        mProviceAdapter = new ProviceAdapter(mContext, mCitys);
        this.mProvicePicker.setViewAdapter(mProviceAdapter);
        this.mProvicePicker.setCurrentItem(0);
        
        this.mCityPicker = (WheelView) mContentView.findViewById(R.id.country_picker);
        this.mCityPicker.setVisibleItems(3);
        this.updateCities(0);
    }

    private void initListener() {
        mProvicePicker.addChangingListener(new OnWheelChangedListener() {
            public void onChanged(WheelView wheel, int oldValue, int newValue) {
                    updateCities(newValue);
            }
        });
    }

    private void updateCities( int index) {
        DebugLog.d("mCitys is null:" + (mCitys == null));
        if (mCitys == null ) {
            return;
        }
        if (mCityAdapter == null) {
        	mCityAdapter = new CountryAdapter(mContext, mCitys.get(index).getAllChild());
        	this.mCityPicker.setViewAdapter(mCityAdapter);
		} else {
			mCityAdapter.setDatas(mCitys.get(index).getAllChild());
			mCityPicker.invalidateWheel(true);
		}
        
        mCityPicker.setCurrentItem(0);
   }

    class CityNode{

        String nodeName;
        List<CityNode> childNodes = new ArrayList<CityNode>();
        public String getNodeName() {
            return nodeName;
        }
        public void setNodeName(String nodeName) {
            this.nodeName = nodeName;
        }

        public List<CityNode> getAllChild(){
            return childNodes;
        }

        public void addChildNode(CityNode node){
            childNodes.add(node);
        }

        public boolean isHaveChild(){
            return childNodes.size() > 0;
        }
    }

    /**
     * Adapter for countries
     */
    private class ProviceAdapter extends AbstractWheelTextAdapter {
        // Countries names
        private List<CityNode> mDatas;
        protected ProviceAdapter(Context context, List<CityNode> citys) {
            super(context, R.layout.city_item_layout, NO_RESOURCE);
            this.mDatas = citys;
            setItemTextResource(R.id.country_name);
        }

        @Override
        public View getItem(int index, View cachedView, ViewGroup parent) {
            View view = super.getItem(index, cachedView, parent);
            return view;
        }

        @Override
        public int getItemsCount() {
            return mDatas.size();
        }

        @Override
        protected CharSequence getItemText(int index) {
            return mDatas.get(index).getNodeName();
        }
    }
    /**
     * Adapter for countries
     */
    private class CountryAdapter extends AbstractWheelTextAdapter {

        private List<CityNode> mDatas;
        protected CountryAdapter(Context context, List<CityNode> datas) {
            super(context, R.layout.city_item_layout, NO_RESOURCE);
            this.mDatas = datas;
            setItemTextResource(R.id.country_name);
        }
        
        public void setDatas(List<CityNode> nodes){
        	mDatas.clear();
        	mDatas.addAll(nodes);
        }

        @Override
        public View getItem(int index, View cachedView, ViewGroup parent) {
            View view = super.getItem(index, cachedView, parent);
            return view;
        }

        @Override
        public int getItemsCount() {
            return mDatas.size();
        }

        @Override
        protected CharSequence getItemText(int index) {
            return mDatas.get(index).getNodeName();
        }
    }

    public interface CitySelectDialogListener {
        public void onSet(String provice, String city);
        public void onCancel();
    }
    
}
