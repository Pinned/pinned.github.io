package cn.lovecluo.widget.form;

import java.util.List;

import cn.lovecluo.tools.JsonParser;

import com.google.gson.reflect.TypeToken;

/** 
 * Create by luozc at Sep 11, 2014
 */
public class FormParser {

    public static List<FormElementModel> parser(String jsonStr){
        return JsonParser.dataToObject(jsonStr, new TypeToken<List<FormElementModel>>() {}.getType());
    }
    
}
