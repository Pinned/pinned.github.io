package cn.lovecluo.widget.form;

import android.content.Context;
import android.view.View;
import cn.lovecluo.nullpointproject.R;

/** 
 * Create by luozc at Sep 12, 2014
 */
public abstract class PickerElement extends BaseFormElement{

    protected Context mContext;
    protected FormElementModel mModel;
    private View mShowView;
    
    
    public PickerElement(Context context, FormElementModel model) {
        super(context, model);
        this.mContext = context;
        this.mModel = model;
        this.preData();
        this.initView();
    }

    protected void preData() {
    }

    private void initView() {
        mShowView = getView();
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        this.addView(mShowView, params);
    }
    protected abstract View getView();

    @Override
    public String getKey() {
        return mModel.getKey();
    }
}
