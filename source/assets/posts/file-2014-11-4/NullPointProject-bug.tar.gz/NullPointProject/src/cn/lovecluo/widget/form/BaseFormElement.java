package cn.lovecluo.widget.form;

import android.content.Context;
import android.widget.LinearLayout;

/** 
 * Create by luozc at Sep 11, 2014
 */
public abstract class BaseFormElement extends LinearLayout {

    public enum ElementPosition {
        TOP,
        MIDDLE
    }
    public BaseFormElement(Context context, FormElementModel model) {
        super(context);
    }

    public abstract String getValue(); 
    public abstract String getKey();
    public abstract boolean checkValue();
}
