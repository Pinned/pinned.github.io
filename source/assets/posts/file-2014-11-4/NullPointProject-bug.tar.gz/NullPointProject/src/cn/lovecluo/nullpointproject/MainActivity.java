package cn.lovecluo.nullpointproject;

import cn.lovecluo.widget.form.FormElementModel;
import cn.lovecluo.widget.form.FormElementModel.ElementType;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.activity_main);
	}
	
	public void showCityDialog(View view) {
		FormElementModel elementModel = new FormElementModel();
		elementModel.setType(ElementType.CITY.toString());
		InputInfoDialog dialog = new InputInfoDialog(this, elementModel);
		dialog.showDialog();
	}
	
}
