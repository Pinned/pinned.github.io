package cn.lovecluo.tools;

import java.lang.reflect.Type;
import java.util.Map;

import com.google.gson.Gson;

/**
 * Created by luozc on Aug 12, 2014
 */

public class JsonParser {

    private static Gson gson = new Gson();
    
	public static <T> T dataToObject(String data, Class<T> clazz) {

		T t = null;
		try {
			t = JsonParser.gson.fromJson(data, clazz);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return t;
	}

	public static <T> T dataToObject(String data, Type type) {
		T t = null;
		try {
			t = JsonParser.gson.fromJson(data, type);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return t;
	}

    public static String toJson(Object obj) {
        return JsonParser.gson.toJson(obj);
    }
}
