package cn.lovecluo.widget.form;

import android.text.TextUtils;

/** 
 * Create by luozc at Sep 11, 2014
 */
public class FormElementModel {

    public enum ElementType{
        CITY(CityPickerElement.class);
        private Class<? extends BaseFormElement> mElementClazz;
        private ElementType(Class<? extends BaseFormElement> mclass) {
            mElementClazz = mclass;
        }
        public  Class<? extends BaseFormElement> getValue(){
            return mElementClazz;
        }
    }
    
    private String mKey;
    private String mLabel;
    private String mDefaultValue;
    private String mHint;
    private ElementType mType;
    private String mError;
    private String mRegex;
    private String mOptions;
    public FormElementModel() {
    }
    
    public FormElementModel(String key,String mLabel, String mDefaultValue, String mHint, String mType,
            String mError, String regex) {
        this.mKey = key;
        this.mLabel = mLabel;
        this.mDefaultValue = mDefaultValue;
        this.mHint = mHint;
        if (TextUtils.isEmpty(mType)) {
			this.mType = ElementType.CITY;
		} else {
			this.mType = ElementType.valueOf(mType);
		}
        this.mError = mError;
        this.mRegex = regex;
    }
    
    public void setKey(String key){
        this.mKey = key;
    }
    public String getKey() {
        return this.mKey;
    }

    public String getOptions() {
        return mOptions;
    }

    public void setOptions(String mOptions) {
        this.mOptions = mOptions;
    }

    public String getLabel() {
        return mLabel;
    }
    public void setLabel(String label) {
        this.mLabel = label;
    }
    public String getDefaultValue() {
        return mDefaultValue;
    }
    public void setDefaultValue(String defaultValue) {
        this.mDefaultValue = defaultValue;
    }
    public ElementType getType() {
        return mType;
    }
    public void setType(String type) {
        this.mType = ElementType.valueOf(type);
    }
    public String getHint() {
        return mHint;
    }
    public void setHint(String hint) {
        this.mHint = hint;
    }
    public String getError() {
        return mError;
    }
    public void setError(String error) {
        this.mError = error;
    }

    public String getRegex() {
        return mRegex;
    }

    public void setRegex(String regex) {
        this.mRegex = regex;
    }
    
    
    
}
